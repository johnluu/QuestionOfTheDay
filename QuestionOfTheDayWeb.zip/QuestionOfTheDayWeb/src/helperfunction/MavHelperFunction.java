package helperfunction;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import qofd.Dao.CommentDAO;
import qofd.Dao.OptionDAO;
import qofd.Dao.QuestionDAO;
import qofd.Dao.UserChoicesDAO;
import qofd.Dao.UserDAO;
import qofd.Dao.UserWatchingDAO;
import qofd.Models.Comments;
import qofd.Models.Option;
import qofd.Models.Question;
import qofd.Models.User;

public class MavHelperFunction {

	public static ModelAndView getQuestionMain(HttpServletRequest request ) throws SQLException  {
		
		
		ModelAndView mav= null;
		
		String type = request.getParameter("menutype");
		if(type == null || type.equals("current"))
		{		type ="current";
				mav = new ModelAndView("questionmain");
		}
		else if(type.equals("archive"))
				mav = new ModelAndView("questionarchivemain");
		
		else if(type.equals("pending"))
			mav = new ModelAndView("pendingquestionmain");
			
		
		
		User user = (User) request.getSession().getAttribute("user");
		QuestionDAO qDAO = new QuestionDAO();
		OptionDAO oDAO = new OptionDAO();
		UserChoicesDAO ucDAO = new UserChoicesDAO();
		UserWatchingDAO uwDAO = new UserWatchingDAO();
		List<Question> QuestionList = null;
		HashMap<Integer, List<Option>> topOption= null;
		HashMap<Integer,Integer> userChoices = null; 
		HashSet<Integer> userWatching = null;
		String sort = request.getParameter("sort");
		
		
		if(sort == null || sort.equals("date"))
			sort = "date";
		else if (sort.equals("rank"))
			sort = "rank";
		
		String Page = request.getParameter("page");
		if(Page == null)
			Page = "1";

		
		int Offset = Integer.parseInt(Page);

		System.out.println("type= " + type +" sort= " + sort + " page = " + Page);
		
		
		
			if(sort.equals("date"))
			{	
			
				if(!type.equals("pending"))
				{
					if(type.equals("archive"))
						Offset = Offset + 7;
				QuestionList = qDAO.getQuestionByDate(Offset);
				topOption = oDAO.getOptionByDate(Offset);
				userChoices = ucDAO.getUserChoice(user.getUser_id());
				}
				else
				{
					QuestionList= qDAO.getPendingByDate(Offset);
					topOption = oDAO.getOptionByDate(Offset);
					userWatching = uwDAO.isWatching(user.getUser_id());
					mav.addObject("userWatching", userWatching);
				}
					

			}
			else if (sort.equals("rank"))
			{
				if(type.equals("current"))
				{
					QuestionList = qDAO.getQuestionByRank(Offset);
					topOption = oDAO.getOptionsByRank(Offset);
					userChoices = ucDAO.getUserChoice(user.getUser_id());
				}
				else if(type.equals("archive"))
				{
					
					QuestionList = qDAO.getArchiveQuestionByRank(Offset);
					topOption = oDAO.getArchiveOptionsByRank(Offset);
					userChoices = ucDAO.getUserChoice(user.getUser_id());
					
				}
				
				else if(type.equals("pending"))
				{
					
					QuestionList= qDAO.getPendingByRank(Offset);
					topOption = oDAO.getOptionByDate(Offset);
					userWatching = uwDAO.isWatching(user.getUser_id());
					mav.addObject("userWatching", userWatching);
					
				}
				
				
			}
		
		
		mav.addObject("sort", sort);
		mav.addObject("page", Page);
		mav.addObject("QuestionList", QuestionList);
		mav.addObject("topOption",topOption);
		mav.addObject("userChoices",userChoices);
		
		return mav;
	}
	
	public static ModelAndView getQuestionSub(HttpServletRequest request ) throws SQLException  {
		

		
		int offset = 1;
		ModelAndView mav= null;
		
		String type = request.getParameter("subtype");
		if(type == null || type.equals("current"))
		{		offset = 1;
				mav = new ModelAndView("questionsub");
		}
		else if(type.equals("archive"))
		{		offset = 8;
				mav = new ModelAndView("questionarchivesub");
				
		}
		
		else if(type.equals("pending"))
			mav = new ModelAndView("pendingquestionsub");
				

		
		User user = (User) request.getSession().getAttribute("user");
		QuestionDAO qDAO = new QuestionDAO();
		OptionDAO oDAO = new OptionDAO();
		UserChoicesDAO ucDAO = new UserChoicesDAO();
		List<Question> QuestionList = null;
		HashMap<Integer, List<Option>> topOption= null;
		UserWatchingDAO uwDAO = new UserWatchingDAO();
		HashMap<Integer,Integer> userChoices = null; 
		HashSet<Integer> userWatching = null;

		
		System.out.println();
		System.out.println("Delivering sub menu things");
		System.out.println(type);

		if(!type.equals("pending"))
		{
				QuestionList = qDAO.getQuestionByDate(offset);
				topOption = oDAO.getOptionByDate(offset);
				userChoices = ucDAO.getUserChoice(user.getUser_id());
		}
		else
		{
			QuestionList= qDAO.getPendingByDate(offset);
			topOption = oDAO.getOptionByDate(offset);
			userWatching = uwDAO.isWatching(user.getUser_id());
			mav.addObject("userWatching", userWatching);
		}
			
			

		
		mav.addObject("QuestionList", QuestionList);
		mav.addObject("topOption",topOption);
		mav.addObject("userChoices",userChoices);
		
		return mav;
	}
	
	public static ModelAndView getQuestion(HttpServletRequest request) throws SQLException, ParseException  {


		System.out.println("111111111111111111111111111111111111");
		
		ModelAndView mav = null;
		
		QuestionDAO qDAO = new QuestionDAO();
		OptionDAO oDAO = new OptionDAO();
		UserDAO uDAO = new UserDAO();
		UserChoicesDAO ucDAO = new UserChoicesDAO();
		CommentDAO cDAO = new CommentDAO();

		Question question = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.0");
		SimpleDateFormat monthformat = new SimpleDateFormat("MMM-dd-yyyy");
		
		String questiontype = "";

		List<Option> options = null;
		int choice = 0;
		User user = (User) request.getSession().getAttribute("user");

		int questionid = Integer.parseInt(request.getParameter("questionid"));
		
		
		question = qDAO.getQuestionById(questionid);
		choice = ucDAO.getUserQChoice(user.getUser_id(), question.getQuestion_id());
		options = oDAO.getOptionsByQuestionId(question.getQuestion_id());
		List<Comments> commentList = cDAO.getQuestionComments(questionid);



		Calendar caldayago = Calendar.getInstance();
		Calendar calweekago = Calendar.getInstance();
		
		caldayago.add(Calendar.DATE, -1);
		calweekago.add(Calendar.DATE, -8);
		
		Date dayago = caldayago.getTime();
		Date weekago = calweekago.getTime();
		Date questiondate = sdf.parse(question.getDate());

		if(questiondate.compareTo(dayago)>0)
		{
			mav = new ModelAndView("pendingquestion");
			
		}
		
		else if(questiondate.compareTo(weekago)<0)
		{
			mav = new ModelAndView("archivedquestion");
		}
		
		else if(questiondate.compareTo(weekago)>=0 && questiondate.compareTo(dayago) <= 0)
		{
			mav = new ModelAndView("currentquestion");
			System.out.println("CURRENT QUESTION" + choice + " " + " " +  options.get(1).getOption_text() + " "  + question.getQuestion_text() + " " + choice);

			
		}
		
		System.out.println("22222222222222");
		
		mav.addObject("question", question);
		mav.addObject("choice", choice);
		mav.addObject("options",options);
		mav.addObject("commentList",commentList);

	
		return mav;
	}
}
