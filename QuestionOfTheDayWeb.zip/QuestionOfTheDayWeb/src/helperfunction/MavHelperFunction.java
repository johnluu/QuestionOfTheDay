package helperfunction;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import qofd.Dao.OptionDAO;
import qofd.Dao.QuestionDAO;
import qofd.Dao.UserChoicesDAO;
import qofd.Models.Option;
import qofd.Models.Question;
import qofd.Models.User;

public class MavHelperFunction {

	public static ModelAndView getQuestionMain(HttpServletRequest request ) throws SQLException  {
		
		ModelAndView mav = new ModelAndView("questionmain");
		User user = (User) request.getSession().getAttribute("user");
		QuestionDAO qDAO = new QuestionDAO();
		OptionDAO oDAO = new OptionDAO();
		UserChoicesDAO ucDAO = new UserChoicesDAO();
		List<Question> QuestionList = null;
		HashMap<Integer, List<Option>> topOption= null;
		HashMap<Integer,Integer> userChoices = null; 
		String sort = request.getParameter("sort");
		
		if(sort == null || sort.equals("date"))
			sort = "date";
		else if (sort.equals("rank"))
			sort = "rank";
		
		String Page = request.getParameter("page");
		if(Page == null)
			Page = "1";
		
			if(sort.equals("date"))
			{
				int dateOffset = Integer.parseInt(Page);
				QuestionList = qDAO.getQuestionByDate(dateOffset);
				topOption = oDAO.getOptionByDate(dateOffset);
				userChoices = ucDAO.getUserChoice(user.getUser_id());
			}
			else if (sort.equals("rank"))
			{
					int rowOffset = Integer.parseInt(Page);
					QuestionList = qDAO.getQuestionByRank(rowOffset);
					topOption = oDAO.getOptionsByRank(rowOffset);
					userChoices = ucDAO.getUserChoice(user.getUser_id());
				
				
			}
		
		
		mav.addObject("sort", sort);
		mav.addObject("page", Page);
		mav.addObject("QuestionList", QuestionList);
		mav.addObject("topOption",topOption);
		mav.addObject("userChoices",userChoices);
		
		return mav;
	}
}
