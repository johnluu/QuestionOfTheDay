package springwork.controller;
import qofd.Dao.*;
import qofd.Models.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	@RequestMapping("/")
	public ModelAndView HomePage()  {
		
		ModelAndView mav = new ModelAndView("HomePage");
		
		return mav;
	}
	
	@RequestMapping(value="/", method = RequestMethod.POST)
	public ModelAndView LoginPage(HttpServletRequest request) throws SQLException {
		ModelAndView mav = new ModelAndView("HomePage");
		UserDAO uDAO = new UserDAO();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		User user = uDAO.loginUser(email, password);
		
		
		if(user != null)
			request.getSession().setAttribute("user", user);
		else
			mav.addObject("message", "Log In Failed");
			
		
		return mav;
	}
	
	
	@RequestMapping("/DashBoard")
	public ModelAndView DashBoard()  {
		
		ModelAndView mav = new ModelAndView("DashBoard");
		
		return mav;
	}

	
	
	@RequestMapping("/QuestionMain")
	public ModelAndView QuestionMain(HttpServletRequest request ) throws SQLException  {
		
		ModelAndView mav = new ModelAndView("questionmain");

		
		User user = (User) request.getSession().getAttribute("user");
		QuestionDAO qDAO = new QuestionDAO();
		OptionDAO oDAO = new OptionDAO();
		UserChoicesDAO ucDAO = new UserChoicesDAO();
		List<Question> QuestionList = null;
		HashMap<Integer, List<Option>> topOption= null;
		HashMap<Integer,Integer> userChoices = null; 
		
		String sort = request.getParameter("sort");
		
		if(sort == null)
			sort = "date";
		
		String Page = request.getParameter("page");
		
		if(Page == null)
			Page = "1";
		
		if(sort.equals("date"))
		{
			
				int dateOffset = Integer.parseInt(Page);
				QuestionList = qDAO.getQuestionByDate(dateOffset);
				topOption = oDAO.getOptionByDate(dateOffset);
				userChoices = ucDAO.getUserChoice(user.getUser_id());
			
			}
			else if (sort.equals("rank"))
			{
					int rowOffset = Integer.parseInt(Page);
					QuestionList = qDAO.getQuestionByRank(rowOffset);
					topOption = oDAO.getOptionsByRank(rowOffset);
					userChoices = ucDAO.getUserChoice(user.getUser_id());
				
				
			}
		
		System.out.println(topOption.get(80));
		mav.addObject("QuestionList", QuestionList);
		mav.addObject("topOption",topOption);
		mav.addObject("userChoices",userChoices);
		
		return mav;
	}
	
	
	

	@RequestMapping(value="/QuestionMainChoice", method = RequestMethod.POST)
	public String QuestionMainChoice(HttpServletRequest request ) throws SQLException  {
		
		User user = (User) request.getSession().getAttribute("user");
		UserChoicesDAO ucDAO = new UserChoicesDAO();

		int questionid = 0;
		int optionid = 0;
		String requestqid = request.getParameter("questionid");
		String requestoid = request.getParameter("optionid");
		
		System.out.println(requestqid + requestoid);
		
		if(requestqid != null)
			questionid = Integer.parseInt(requestqid);
		if(requestoid != null)
			optionid = Integer.parseInt(requestoid);
		
		int userid = user.getUser_id();
		
		int userchoice = ucDAO.getUserQChoice(userid, questionid);	
		
		System.out.println(questionid+ " " + optionid + " " + userchoice + " " + userid);
		if(optionid != 0)
		{
		if(userchoice == 0)
			ucDAO.createUserChoice(userid, questionid, optionid);
		else
			ucDAO.changeUserChoice(userid, questionid, userchoice, optionid);
		}
		return "questionmain";
	}
	

}




