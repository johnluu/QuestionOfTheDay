package springwork.controller;
import qofd.Dao.*;
import qofd.Models.*;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import helperfunction.MavHelperFunction;

@Controller
public class HomeController {
	@RequestMapping("/")
	public ModelAndView HomePage()  {
		
		ModelAndView mav = new ModelAndView("HomePage");
		
		return mav;
	}
	
	@RequestMapping(value="/", method = RequestMethod.POST)
	public ModelAndView LoginPage(HttpServletRequest request) throws SQLException {
		ModelAndView mav = new ModelAndView("HomePage");
		UserDAO uDAO = new UserDAO();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		User user = uDAO.loginUser(email, password);
		
		
		if(user != null)
			request.getSession().setAttribute("user", user);
		else
			mav.addObject("message", "Log In Failed");
			
		
		return mav;
	}
	
	
	@RequestMapping("/DashBoard")
	public ModelAndView DashBoard()  {
		
		ModelAndView mav = new ModelAndView("DashBoard");
		
		return mav;
	}

	
	
	@RequestMapping("/QuestionMain")
	public ModelAndView QuestionMain(HttpServletRequest request ) throws SQLException  {
		
		ModelAndView mav = MavHelperFunction.getQuestionMain(request);
		
		System.out.println();
		System.out.println("Delivering things");

		
		

		return mav;
	}
	
	@RequestMapping("/QuestionSub")
	public ModelAndView QuestionSub(HttpServletRequest request ) throws SQLException  {
		
		ModelAndView mav = MavHelperFunction.getQuestionSub(request);
		

		
		return mav;
	}
	
	
	

	@RequestMapping(value="/QuestionMainChoice", method = RequestMethod.POST)
	public ModelAndView QuestionMainChoice(HttpServletRequest request ) throws SQLException  {
		
		ModelAndView mav = null;
		
		User user = (User) request.getSession().getAttribute("user");
		UserChoicesDAO ucDAO = new UserChoicesDAO();

		int questionid = 0;
		int optionid = 0;
		String requestqid =  request.getParameter("questionid");
		String requestoid =  request.getParameter("optionid");
		
		System.out.println(requestqid + requestoid);
		
		if(requestqid != null)
			questionid = Integer.parseInt(requestqid);
		if(requestoid != null)
			optionid = Integer.parseInt(requestoid);
		
		
		int userid = user.getUser_id();
		
		int userchoice = ucDAO.getUserQChoice(userid, questionid);	
		
		System.out.println(questionid+ " " + optionid + " " + userchoice + " " + userid);
		if(optionid != 0)
		{
		if(userchoice == 0)
			ucDAO.createUserChoice(userid, questionid, optionid);
		else
			ucDAO.changeUserChoice(userid, questionid, userchoice, optionid);
		}
		System.out.println("completed - returning");
		
		String type = request.getParameter("type");
		if(type == null || type.equals("main"))
		 mav = MavHelperFunction.getQuestionMain(request);
		
		else
		 mav = MavHelperFunction.getQuestionSub(request);

		return mav;
	}
	
	@RequestMapping(value="/QuestionWatch", method = RequestMethod.POST)
	public ModelAndView QuestionWatch(HttpServletRequest request ) throws SQLException  {
		
		System.out.println("completed - returning");
		
		ModelAndView mav = null;
		
		UserWatchingDAO uwDAO = new UserWatchingDAO();
			
		User user = (User) request.getSession().getAttribute("user");

		int userid = user.getUser_id();
		
		int questionid = 0;
		String requestqid =  request.getParameter("questionid");
		
		String watching = null;
		watching = request.getParameter("watching");
		
		if(requestqid != null)
			questionid = Integer.parseInt(requestqid);
		
		System.out.println("watching ="+  watching + " userid = " + userid + "questionid=" + questionid) ;

		

		

		
		if(watching.equals("UnWatch"))
			uwDAO.unwatch(user.getUser_id(), questionid);
		else
			uwDAO.watch(user.getUser_id(), questionid);

		
		
		


		
		
		String type = request.getParameter("type");
		if(type == null || type.equals("main"))
		 mav = MavHelperFunction.getQuestionMain(request);
		
		else
		 mav = MavHelperFunction.getQuestionSub(request);

		return mav;
	}
	
}




