package qofd.SystemInterfaces;

import java.sql.SQLException;

import qofd.Models.User;

public interface UserDAOI {

	public int registerUser (User user) throws SQLException;
	public User loginUser(String email,String password) throws SQLException;
	public User getUser(int userid) throws SQLException;
	public int removeUser(int userid) throws SQLException;
	int[] getUserFollowing(int userid) throws SQLException;
	
	
}
