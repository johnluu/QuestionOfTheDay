package qofd.Dao.testcases;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.sql.SQLException;
import java.util.HashSet;

import org.junit.Test;

import qofd.Dao.UserWatchingDAO;

public class UserWatchingDAOTest {

	
	@Test
	public void userChoiceTest() throws SQLException {
		UserWatchingDAO uwDAO = new UserWatchingDAO();
		
		int watching = uwDAO.watch(1, 80);
		HashSet<Integer> userwatching = uwDAO.isWatching(1);
		userwatching.contains(80);
		assertThat(userwatching.contains(80), is(equalTo(true)));
		uwDAO.unwatch(1, 80);
		userwatching = uwDAO.isWatching(1);
		assertThat(userwatching.contains(80), is(equalTo(false)));
	
	}
	
	
	
	
	
	
	
	
}
