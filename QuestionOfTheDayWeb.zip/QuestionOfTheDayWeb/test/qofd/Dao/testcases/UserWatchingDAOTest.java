package qofd.Dao.testcases;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.MatcherAssert.assertThat;
import qofd.Dao.UserChoicesDAO;

public class UserWatchingDAOTest {

	
	
	
	
	
	
	
	
	
	
}
