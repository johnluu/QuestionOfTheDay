package qofd.Dao.testcases;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;

import java.sql.SQLException;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import qofd.Dao.QuestionDAO;
import qofd.Models.Question;

public class QuestionDAOTest {

	@Test
	public void testDAO() throws SQLException {
		QuestionDAO qDAO = new QuestionDAO();
		
		int userid = 1;
		String questiontext = "FavConsole";
		
		int qid = qDAO.createNewQuestion(userid, questiontext);
	
		Question question = qDAO.getQuestionById(qid);
		
		assertThat(question.getQuestion_id(), is(equalTo(qid)));
		assertThat(question.getUser_id(), is(equalTo(userid)));
		assertThat(question.getQuestion_text(), is(equalTo(questiontext)));

		
		assertThat(qDAO.deleteQuestion(qid), is(equalTo(true)));
		  
		
	}
	
}
